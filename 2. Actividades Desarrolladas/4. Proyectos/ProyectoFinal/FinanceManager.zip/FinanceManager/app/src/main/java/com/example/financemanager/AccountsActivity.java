package com.example.financemanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.financemanager.models.Account;

import java.util.List;

public class AccountsActivity extends AppCompatActivity {
    private DBHelper dbHelper; // Se inicializará en onCreate
    private AlertDialog dialog;
    private LinearLayout accountsContainer;
    private ImageButton btnHome;
    private ImageButton btnCategories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.accounts_activity);

        dbHelper = new DBHelper(this);
        accountsContainer = findViewById(R.id.AccountsContainer);

        btnCategories = findViewById(R.id.btnCategories);
        btnCategories.setOnClickListener(v -> startCategoriesActivity());

        btnHome = findViewById(R.id.btnHome);
        btnHome.setOnClickListener(v -> startMainActivity());

        ImageButton btnAdd = findViewById(R.id.btnAddAccount);
        btnAdd.setOnClickListener(v -> showAccountForm());

        loadAccounts();
    }

    private void startMainActivity() {
        Intent intent = new Intent(AccountsActivity.this, MainActivity.class);
        startActivity(intent);
    }

    private void startCategoriesActivity() {
        Intent intent = new Intent(AccountsActivity.this, CategoriesActivity.class);
        startActivity(intent);
    }

    private void loadAccounts() {
        List<Account> accounts = dbHelper.getAllAccounts();
        accountsContainer.removeAllViews();

        for (Account account : accounts) {
            String accountName = account.getName();
            addAccountBubble(accountName);
        }
    }

    private void addAccountBubble(String accountName) {
        View accountBubbleView = getLayoutInflater().inflate(R.layout.account_bubble, null);
        TextView tvAccountName = accountBubbleView.findViewById(R.id.tvAccountName);
        tvAccountName.setText(accountName);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(8, 8, 8, 8);
        accountBubbleView.setLayoutParams(layoutParams);

        accountsContainer.addView(accountBubbleView);

        accountBubbleView.setOnLongClickListener(v -> {
            showEditOrDeleteDialog(accountName);
            return true;
        });
    }

    private void showAccountForm() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.account_form, null); // Cambiado a account_form
        builder.setView(dialogView);

        EditText etName = dialogView.findViewById(R.id.etName);

        ImageButton btnCancel = dialogView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(v -> dialog.dismiss());

        ImageButton btnConfirm = dialogView.findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(v -> {
            String accountName = etName.getText().toString().trim();
            if (!accountName.isEmpty()) {
                insertAccount(accountName);
                dialog.dismiss();
            } else {
                Toast.makeText(AccountsActivity.this, "Ingrese un nombre para la cuenta", Toast.LENGTH_SHORT).show();
            }
        });

        dialog = builder.create();
        dialog.show();
    }

    private void insertAccount(String accountName) {
        long result = dbHelper.insertAccount(accountName);

        if (result != -1) {
            Toast.makeText(this, "Cuenta agregada correctamente", Toast.LENGTH_SHORT).show();
            loadAccounts();
        } else {
            Toast.makeText(this, "Error al agregar cuenta", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmationDialog(final String accountName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar eliminación");
        builder.setMessage("¿Estás seguro de que deseas eliminar esta cuenta?");
        builder.setPositiveButton("Eliminar", (dialogInterface, i) -> {
            deleteAccount(accountName);
            dialogInterface.dismiss();
        });
        builder.setNegativeButton("Cancelar", (dialogInterface, i) -> dialogInterface.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void deleteAccount(String accountName) {
        boolean deleted = dbHelper.deleteAccount(accountName);

        if (deleted) {
            Toast.makeText(this, "Cuenta eliminada correctamente", Toast.LENGTH_SHORT).show();
            loadAccounts();
        } else {
            Toast.makeText(this, "Error al eliminar la cuenta", Toast.LENGTH_SHORT).show();
        }
    }

    private void showEditOrDeleteDialog(String accountName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Opciones");
        String[] options = {"Editar", "Eliminar"};
        builder.setItems(options, (dialogInterface, i) -> {
            if (i == 0) {
                editAccount(accountName);
            } else if (i == 1) {
                showDeleteConfirmationDialog(accountName);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void editAccount(String accountName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.account_form, null);
        builder.setView(dialogView);

        EditText etName = dialogView.findViewById(R.id.etName);
        etName.setText(accountName);

        ImageButton btnCancel = dialogView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(v -> dialog.dismiss());

        ImageButton btnConfirm = dialogView.findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(v -> {
            String updatedName = etName.getText().toString().trim();
            if (!updatedName.isEmpty()) {
                updateAccount(accountName, updatedName);
                dialog.dismiss();
            } else {
                Toast.makeText(AccountsActivity.this, "Ingrese un nombre para la cuenta", Toast.LENGTH_SHORT).show();
            }
        });

        dialog = builder.create();
        dialog.show();
    }

    private void updateAccount(String oldName, String newName) {
        boolean updated = dbHelper.updateAccount(oldName, newName);

        if (updated) {
            Toast.makeText(this, "Cuenta actualizada correctamente", Toast.LENGTH_SHORT).show();
            loadAccounts();
        } else {
            Toast.makeText(this, "Error al actualizar la cuenta", Toast.LENGTH_SHORT).show();
        }
    }
}

