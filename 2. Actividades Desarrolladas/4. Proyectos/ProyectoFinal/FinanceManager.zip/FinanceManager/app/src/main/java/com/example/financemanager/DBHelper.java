package com.example.financemanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.financemanager.models.Account;
import com.example.financemanager.models.Category;
import com.example.financemanager.models.Transaction;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "financesManager.db";
    private static final int DATABASE_VERSION = 3;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear la estructura de la base de datos al crearla por primera vez

        // Tabla Accounts
        db.execSQL("CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)");

        // Tabla Categories
        db.execSQL("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)");

        // Tabla Transactions
        db.execSQL("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, accountId INTEGER, categoryId INTEGER NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL, type INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS accounts");
        db.execSQL("DROP TABLE IF EXISTS categories");
        db.execSQL("DROP TABLE IF EXISTS transactions");

        onCreate(db);
    }

    // Método para obtener la lista de nombres de categorías con sus IDs
    public List<Account> getAllAccounts() {
        List<Account> accountsList = new ArrayList<>();

        // Obtener una referencia de la base de datos en modo lectura
        SQLiteDatabase db = this.getReadableDatabase();

        // Consulta para obtener los nombres de categorías con sus IDs
        Cursor cursor = db.query("accounts", new String[]{"id", "name"}, null, null, null, null, null);

        // Verificar si hay resultados y agregarlos a la lista
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int accountId = cursor.getInt(cursor.getColumnIndex("id"));
                String accountName = cursor.getString(cursor.getColumnIndex("name"));
                Account account = new Account(accountId, accountName);
                accountsList.add(account);
            } while (cursor.moveToNext());
            cursor.close();
        }

        // Cerrar la conexión de la base de datos
        db.close();

        return accountsList;
    }

    public long insertAccount(String accountName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", accountName);

        long result = db.insert("accounts", null, values);
        db.close();

        return result;
    }

    // Método para eliminar una categoría de la base de datos
    public boolean deleteAccount(String accountName) {
        String tableName = "accounts";
        String columnName = "name";

        // Obtiene la base de datos en modo de escritura
        SQLiteDatabase db = this.getWritableDatabase();

        // Define la cláusula WHERE para la consulta SQL
        String selection = columnName + " = ?";
        String[] selectionArgs = { accountName };

        // Realiza la eliminación
        int deletedRows = db.delete(tableName, selection, selectionArgs);

        // Cierra la conexión a la base de datos
        db.close();

        // Devuelve true si se eliminó al menos una fila, de lo contrario false
        return deletedRows > 0;
    }

    public boolean updateAccount(String oldAccountName, String newAccountName) {
        String tableName = "accounts";
        String columnName = "name";

        // Obtiene la base de datos en modo de escritura
        SQLiteDatabase db = this.getWritableDatabase();

        // Crea un objeto ContentValues para almacenar los nuevos valores
        ContentValues values = new ContentValues();
        values.put(columnName, newAccountName); // Asigna el nuevo nombre de la categoría

        // Define la cláusula WHERE para la consulta SQL
        String selection = columnName + " = ?";
        String[] selectionArgs = { oldAccountName };

        // Realiza la actualización
        int updatedRows = db.update(tableName, values, selection, selectionArgs);

        // Cierra la conexión a la base de datos
        db.close();

        // Devuelve true si se actualizó al menos una fila, de lo contrario false
        return updatedRows > 0;
    }

    // Método para obtener la lista de Cuentas con sus IDs
    public List<Category> getAllCategories() {
        List<Category> categoriesList = new ArrayList<>();

        // Obtener una referencia de la base de datos en modo lectura
        SQLiteDatabase db = this.getReadableDatabase();

        // Consulta para obtener los nombres de categorías con sus IDs
        Cursor cursor = db.query("categories", new String[]{"id", "name"}, null, null, null, null, null);

        // Verificar si hay resultados y agregarlos a la lista
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int categoryId = cursor.getInt(cursor.getColumnIndex("id"));
                String categoryName = cursor.getString(cursor.getColumnIndex("name"));
                Category category = new Category(categoryId, categoryName);
                categoriesList.add(category);
            } while (cursor.moveToNext());
            cursor.close();
        }

        // Cerrar la conexión de la base de datos
        db.close();

        return categoriesList;
    }

    public long insertCategory(String categoryName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", categoryName);

        long result = db.insert("categories", null, values);
        db.close();

        return result;
    }

    // Método para eliminar una categoría de la base de datos
    public boolean deleteCategory(String categoryName) {
        String tableName = "categories";
        String columnName = "name";

        // Obtiene la base de datos en modo de escritura
        SQLiteDatabase db = this.getWritableDatabase();

        // Define la cláusula WHERE para la consulta SQL
        String selection = columnName + " = ?";
        String[] selectionArgs = { categoryName };

        // Realiza la eliminación
        int deletedRows = db.delete(tableName, selection, selectionArgs);

        // Cierra la conexión a la base de datos
        db.close();

        // Devuelve true si se eliminó al menos una fila, de lo contrario false
        return deletedRows > 0;
    }

    public boolean updateCategory(String oldCategoryName, String newCategoryName) {
        String tableName = "categories";
        String columnName = "name";

        // Obtiene la base de datos en modo de escritura
        SQLiteDatabase db = this.getWritableDatabase();

        // Crea un objeto ContentValues para almacenar los nuevos valores
        ContentValues values = new ContentValues();
        values.put(columnName, newCategoryName); // Asigna el nuevo nombre de la categoría

        // Define la cláusula WHERE para la consulta SQL
        String selection = columnName + " = ?";
        String[] selectionArgs = { oldCategoryName };

        // Realiza la actualización
        int updatedRows = db.update(tableName, values, selection, selectionArgs);

        // Cierra la conexión a la base de datos
        db.close();

        // Devuelve true si se actualizó al menos una fila, de lo contrario false
        return updatedRows > 0;
    }

    public boolean insertTransaction(Transaction transaction) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("accountId", transaction.getAccountId());
        values.put("categoryId", transaction.getCategoryId());
        values.put("description", transaction.getDescription());
        values.put("amount", transaction.getAmount());
        values.put("type", transaction.getType());

        // Insertar la fila en la tabla
        long result = db.insert("transactions", null, values);

        // Verificar si la inserción fue exitosa
        boolean success = result != -1;

        // Cerrar la conexión a la base de datos
        db.close();

        return success;
    }

    public List<Transaction> getAllTransactionsByAccountId(int accountId) {
        List<Transaction> transactionsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                "id",
                "categoryId",
                "description",
                "amount",
                "type",
                "accountId"
        };

        // Filtro para obtener solo las transacciones del accountId especificado
        String selection = "accountId = ?";
        String[] selectionArgs = { String.valueOf(accountId) };

        Cursor cursor = db.query(
                "transactions",  // Nombre de la tabla
                projection,      // Columnas
                selection,       // Cláusula WHERE
                selectionArgs,   // Valores de la cláusula WHERE
                null,
                null,
                null
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                int category = cursor.getInt(cursor.getColumnIndexOrThrow("categoryId"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                double amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount"));
                int type = cursor.getInt(cursor.getColumnIndexOrThrow("type"));
                int account_id = cursor.getInt(cursor.getColumnIndexOrThrow("accountId"));

                // Crear objeto Transaction y agregarlo a la lista
                Transaction transaction = new Transaction(id, account_id, category, description, amount, type);
                transactionsList.add(transaction);
            }
            cursor.close();
        }

        return transactionsList;
    }

    public String getCategoryNameById(int categoryId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = { "name" }; // Nombre de la columna de nombre de categoría
        String selection = "id = ?";
        String[] selectionArgs = { String.valueOf(categoryId) };

        Cursor cursor = db.query(
                "categories",  // Nombre de la tabla de categorías
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        String categoryName = null;
        if (cursor != null && cursor.moveToFirst()) {
            categoryName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            cursor.close();
        }
        return categoryName;
    }

}
