package com.example.financemanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.financemanager.models.Category;

import java.util.List;

public class CategoriesActivity extends AppCompatActivity {
    private DBHelper dbHelper = new DBHelper(this);
    private AlertDialog dialog;
    private LinearLayout llCategoriesContainer;

    private ImageButton btnHome;
    private ImageButton btnAccounts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.categories_activity);

        llCategoriesContainer = findViewById(R.id.llCategoriesContainer);

        // Obtener la referencia al botón "Accounts"
        btnAccounts = findViewById(R.id.btnAccounts);

        // Configurar OnClickListener para el botón "Accounts"
        btnAccounts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startAccountsActivity(); // Llama al método para iniciar CategoriesActivity
            }
        });

        // Obtener la referencia al botón "Home"
        btnHome = findViewById(R.id.btnHome);

        // Configurar OnClickListener para el botón "Home"
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMainActivity(); // Llama al método para iniciar CategoriesActivity
            }
        });

        // Obtener referencia al botón btnAdd
        ImageButton btnAdd = findViewById(R.id.btnAddCategory);

        // Agregar OnClickListener al botón btnAdd
        btnAdd.setOnClickListener(v -> {
            showCategoryForm();
        });

        // Cargar y mostrar las categorías
        loadCategories();
    }

    // Método para iniciar MainActivity
    private void startMainActivity() {
        Intent intent = new Intent(CategoriesActivity.this, MainActivity.class);
        startActivity(intent);
    }

    // Método para iniciar AccountsActivity
    private void startAccountsActivity() {
        Intent intent = new Intent(CategoriesActivity.this, AccountsActivity.class);
        startActivity(intent);
    }

    private void loadCategories() {
        // Obtener las categorías de la base de datos
        List<Category> categories = dbHelper.getAllCategories();

        // Limpiar el contenedor antes de agregar nuevas vistas
        llCategoriesContainer.removeAllViews();

        // Recorrer la lista de categorías y crear vistas dinámicamente
        for (Category category : categories) {
            String categoryName = category.getName(); // Obtener el nombre de la categoría
            addCategoryBubble(categoryName); // Agregar la vista de la categoría
        }
    }

    private void addCategoryBubble(String categoryName) {
        // Inflar el layout de la burbuja de categoría
        View categoryBubbleView = getLayoutInflater().inflate(R.layout.category_bubble, null);

        // Configurar el texto con el nombre de la categoría
        TextView tvCategoryName = categoryBubbleView.findViewById(R.id.tvCategoryName);
        tvCategoryName.setText(categoryName);

        // Configurar márgenes dinámicamente (ejemplo con 8dp en todos los lados)
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(8, 8, 8, 8); // Left, Top, Right, Bottom

        // Aplicar los parámetros de diseño al contenedor de la burbuja
        categoryBubbleView.setLayoutParams(layoutParams);

        // Agregar la vista de burbuja al contenedor
        llCategoriesContainer.addView(categoryBubbleView);

        // Configurar la acción de mantener presionada para editar o borrar la categoría
        categoryBubbleView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showEditOrDeleteDialog(categoryName);
                return true;
            }
        });
    }

    private void showCategoryForm() {
        // Crear un objeto AlertDialog para la ventana flotante
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
        LayoutInflater inflater = getLayoutInflater();

        // Inflar el layout de la ventana flotante
        View dialogView = inflater.inflate(R.layout.category_form, null);
        builder.setView(dialogView);

        // Obtener referencia al EditText etName
        EditText etName = dialogView.findViewById(R.id.etName);

        // Configurar el botón "Cancelar"
        ImageButton btnCancel = dialogView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cerrar el diálogo al hacer clic en "Cancelar"
                dialog.dismiss();
            }
        });

        // Configurar el botón "Confirmar"
        ImageButton btnConfirm = dialogView.findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el valor del EditText
                String categoryName = etName.getText().toString().trim();

                // Insertar en la base de datos si el nombre no está vacío
                if (!categoryName.isEmpty()) {
                    insertCategory(categoryName);
                    dialog.dismiss();
                } else {
                    // Mostrar mensaje de error si el nombre está vacío
                    Toast.makeText(CategoriesActivity.this, "Ingrese un nombre para la categoría", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Crear y mostrar el AlertDialog
        dialog = builder.create();
        dialog.show();
    }

    private void insertCategory(String categoryName) {
        // Insertar el nombre de la categoría en la base de datos
        long result = dbHelper.insertCategory(categoryName);

        if (result != -1) {
            // Éxito al insertar la categoría
            Toast.makeText(this, "Categoría agregada correctamente", Toast.LENGTH_SHORT).show();

            // Actualizar la vista de las categorías
            loadCategories();
        } else {
            // Error al insertar la categoría
            Toast.makeText(this, "Error al agregar categoría", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para mostrar un diálogo de confirmación al eliminar una categoría
    private void showDeleteConfirmationDialog(final String categoryName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar eliminación");
        builder.setMessage("¿Estás seguro de que deseas eliminar esta categoría?");
        builder.setPositiveButton("Eliminar", (dialogInterface, i) -> {
            deleteCategory(categoryName);
            dialogInterface.dismiss();
        });
        builder.setNegativeButton("Cancelar", (dialogInterface, i) -> dialogInterface.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
        // Aplicar el color de fondo al diálogo
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.add_category_form);
    }


    // Método para eliminar una categoría
    private void deleteCategory(String categoryName) {
        // Eliminar la categoría de la base de datos
        boolean deleted = dbHelper.deleteCategory(categoryName);

        if (deleted) {
            Toast.makeText(this, "Categoría eliminada correctamente", Toast.LENGTH_SHORT).show();
            // Actualizar la vista de las categorías
            loadCategories();
        } else {
            Toast.makeText(this, "Error al eliminar la categoría", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para editar una categoría
    private void editCategory(String categoryName) {
        // Mostrar un diálogo similar a category_form para editar la categoría
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.category_form, null);
        builder.setView(dialogView);

        // Obtener referencia al EditText etName y establecer el nombre actual
        EditText etName = dialogView.findViewById(R.id.etName);
        etName.setText(categoryName);

        // Configurar el botón "Cancelar" para cerrar el diálogo
        ImageButton btnCancel = dialogView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(v -> dialog.dismiss());

        // Configurar el botón "Confirmar" para realizar la actualización
        ImageButton btnConfirm = dialogView.findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(v -> {
            String updatedName = etName.getText().toString().trim();
            if (!updatedName.isEmpty()) {
                updateCategory(categoryName, updatedName);
                dialog.dismiss();
            } else {
                Toast.makeText(CategoriesActivity.this, "Ingrese un nombre para la categoría", Toast.LENGTH_SHORT).show();
            }
        });

        // Crear y mostrar el AlertDialog
        dialog = builder.create();
        dialog.show();
    }

    // Método para actualizar una categoría
    private void updateCategory(String oldName, String newName) {
        // Actualizar la categoría en la base de datos
        boolean updated = dbHelper.updateCategory(oldName, newName);

        if (updated) {
            Toast.makeText(this, "Categoría actualizada correctamente", Toast.LENGTH_SHORT).show();
            // Actualizar la vista de las categorías
            loadCategories();
        } else {
            Toast.makeText(this, "Error al actualizar la categoría", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para mostrar el diálogo de edición o eliminación al mantener presionada una burbuja
    private void showEditOrDeleteDialog(String categoryName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Opciones");
        String[] options = {"Editar", "Eliminar"};
        builder.setItems(options, (dialogInterface, i) -> {
            if (i == 0) {
                // Editar categoría
                editCategory(categoryName);
            } else if (i == 1) {
                // Mostrar diálogo de confirmación antes de eliminar
                showDeleteConfirmationDialog(categoryName);
            }
        });

        // Asignar el fondo al diálogo
        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.add_category_form);
        dialog.show();
    }
}
