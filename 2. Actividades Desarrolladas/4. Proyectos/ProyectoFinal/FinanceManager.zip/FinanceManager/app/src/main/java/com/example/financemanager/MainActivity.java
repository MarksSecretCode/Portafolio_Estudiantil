package com.example.financemanager;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.financemanager.models.Account;
import com.example.financemanager.models.Category;
import com.example.financemanager.models.Transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    // Instancia de DbHelper
    private DBHelper dbHelper = new DBHelper(this);
    private LinearLayout transactionsContainer;
    private ImageButton btnCategories;
    private ImageButton btnAccounts;
    private Spinner spnAccount;


    private int accountId = -1;
    private int categoryId = -1;

    private Map<String, Integer> accountMap = new HashMap<>();

    private List<Transaction> transactionsList;

    private double totalBalance = 0;

    private TextView tvBalance;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Obtener Referencia del TransactionsContainer
        transactionsContainer = findViewById(R.id.TransactionsContainer);

        // Obtener referencia al Spinner
        spnAccount = findViewById(R.id.spnAccount);

        // Obtener referencia al TextView tvBalance
        tvBalance = findViewById(R.id.tvBalance);

        // Cargar y mostrar las cuentas en el Spinner
        loadAccounts();

        // Obtener referencia al ScrollView
        ScrollView scrollView = findViewById(R.id.scvTransactions);

        // Configurar listener para el Spinner
        spnAccount.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Obtener el nombre de la cuenta seleccionada
                String accountName = (String) parent.getItemAtPosition(position);
                // Obtener el categoryId del mapa utilizando el nombre de la categoría seleccionada
                accountId = accountMap.get(accountName);
                // Mostrar mensaje con la cuenta seleccionada (solo como ejemplo)
                Toast.makeText(MainActivity.this, "Cuenta seleccionada: " + accountName, Toast.LENGTH_SHORT).show();
                // Cargar las transacciones
                loadTransactionsByAccountId();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                accountId = -1;
            }
        });

        // Obtener referencia al botón btnAdd
        ImageButton btnAdd = findViewById(R.id.btnAdd);

        // Agregar OnClickListener al botón btnAdd
        btnAdd.setOnClickListener(v -> {
            showTransactionForm(1);
        });

        // Obtener la referencia al botón "Categories"
        btnCategories = findViewById(R.id.btnCategories);

        // Configurar OnClickListener para el botón "Categories"
        btnCategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCategoriesActivity(); // Llama al método para iniciar CategoriesActivity
            }
        });

        // Obtener la referencia al botón "Accounts"
        btnAccounts = findViewById(R.id.btnAccounts);

        // Configurar OnClickListener para el botón "Categories"
        btnAccounts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startAccountsActivity(); // Llama al método para iniciar CategoriesActivity
            }
        });

        // Obtener la referencia al botón btnMinus
        ImageButton btnMinus = findViewById(R.id.btnMinus);

        // Configurar OnClickListener para el botón btnMinus
        btnMinus.setOnClickListener(v -> {
            showTransactionForm(0);
        });


    }

    private void loadTransactionsByAccountId() {
        if (accountId != -1){
            // Llenar lista de transacciones
            transactionsList = dbHelper.getAllTransactionsByAccountId(accountId);
            // Mostrar un Toast para verificar que la lista se ha llenado
            //Toast.makeText(this, "Transacciones cargadas: " + transactionsList.size(), Toast.LENGTH_SHORT).show();

            transactionsContainer.removeAllViews();

            for (Transaction transaction : transactionsList) {
                // Agregar un Toast para mostrar el nombre de la cuenta que se está procesando
                String transactionDescription = transaction.getDescription();
                String transactionCategoryName = dbHelper.getCategoryNameById(transaction.getCategoryId());
                double transactionAmount = transaction.getAmount();
                int transactionType = transaction.getType();
                addTransactionBubble(transactionDescription, transactionCategoryName, transactionAmount, transactionType);
            }
            // Calcular el balance total
            totalBalance = calculateTotalAmount();
        }
    }

    private void addTransactionBubble(String transactionDescription, String transactionCategoryName, double transactionAmount, int type) {
        View transactionBubbleView = getLayoutInflater().inflate(R.layout.transaction_bubble, null);
        LinearLayout transactionBubbleLayout = transactionBubbleView.findViewById(R.id.transactionBubbleLayout);
        TextView tvTransactionDescription = transactionBubbleView.findViewById(R.id.tvTransactionDescription);
        TextView tvTransactionCategory = transactionBubbleView.findViewById(R.id.tvTransactionCategory);
        TextView tvTransactionAmount = transactionBubbleView.findViewById(R.id.tvTransactionAmount);

        tvTransactionDescription.setText(transactionDescription);
        tvTransactionCategory.setText(transactionCategoryName);
        tvTransactionAmount.setText(String.valueOf(transactionAmount));

        // Obtener el color de fondo desde resources
        int color;
        if(type == 1){
            color = ContextCompat.getColor(this, R.color.greenTransaction);
        } else {
            color = ContextCompat.getColor(this, R.color.redTransaction);
        }

        // Convertir el color a ColorStateList
        ColorStateList colorStateList = ColorStateList.valueOf(color);

        // Establecer la ColorStateList como fondo tint
        ViewCompat.setBackgroundTintList(transactionBubbleLayout, colorStateList);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(8, 8, 8, 8);
        transactionBubbleView.setLayoutParams(layoutParams);

        transactionsContainer.addView(transactionBubbleView);

        /*transactionBubbleView.setOnLongClickListener(v -> {
            showEditOrDeleteDialog(accountName);
            return true;
        });*/
    }


    // Método para iniciar CategoriesActivity
    private void startCategoriesActivity() {
        Intent intent = new Intent(MainActivity.this, CategoriesActivity.class);
        startActivity(intent);
    }

    // Método para iniciar AccountsActivity
    private void startAccountsActivity() {
        Intent intent = new Intent(MainActivity.this, AccountsActivity.class);
        startActivity(intent);
    }

    private void showTransactionForm(int type) {
        // Crear un objeto AlertDialog para la ventana flotante
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
        LayoutInflater inflater = getLayoutInflater();

        // Inflar el layout de la ventana flotante
        View dialogView = inflater.inflate(R.layout.income_transaction_form, null);
        builder.setView(dialogView);

        // Obtener referencias a las vistas del layout
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinnerCategory);
        EditText etDescription = dialogView.findViewById(R.id.etDescription);
        EditText etAmount = dialogView.findViewById(R.id.etAmount);

        // Obtener las categorías de la base de datos
        List<Category> categories = dbHelper.getAllCategories();

        // Declarar lista para almacenar los nombres de las categorías
        List<String> categoryNames = new ArrayList<>();

        // Llenar lista de nombres y crear un mapa para asociar nombres con IDs
        Map<String, Integer> categoryMap = new HashMap<>();
        for (Category category : categories) {
            categoryNames.add(category.getName());
            categoryMap.put(category.getName(), category.getId());
        }

        // Crear un ArrayAdapter para el spinner y establecerlo
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categoryNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        // Configurar el listener para el Spinner
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Obtener el nombre de la categoría seleccionada
                String categoryName = (String) parent.getItemAtPosition(position);
                // Obtener el categoryId del mapa utilizando el nombre de la categoría seleccionada
                categoryId = categoryMap.get(categoryName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Crear AlertDialog
        AlertDialog dialog = builder.create();

        // Cambiar el color del fondo del diálogo según el tipo
        LinearLayout transactionFormLayout = dialogView.findViewById(R.id.transactionFormLayout);
        if (type == 1) {
            // Obtener el color de fondo desde resources
            int colorGreen = ContextCompat.getColor(this, R.color.greenTransaction);

            // Convertir el color a ColorStateList
            ColorStateList colorStateList = ColorStateList.valueOf(colorGreen);

            // Establecer la ColorStateList como fondo tint
            ViewCompat.setBackgroundTintList(transactionFormLayout, colorStateList);
        } else if (type == 0) {
            // Obtener el color de fondo desde resources
            int colorRed = ContextCompat.getColor(this, R.color.redTransaction);

            // Convertir el color a ColorStateList
            ColorStateList colorStateList = ColorStateList.valueOf(colorRed);

            // Establecer la ColorStateList como fondo tint
            ViewCompat.setBackgroundTintList(transactionFormLayout, colorStateList);
        }

        // Mostrar AlertDialog
        dialog.show();

        // Configurar el botón "Cancelar"
        ImageButton btnCancel = dialogView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cerrar el diálogo al hacer clic en "Cancelar"
                dialog.dismiss();
            }
        });

        // Configurar el botón "Confirmar"
        ImageButton btnConfirm = dialogView.findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el texto dentro del EditText
                String descripcion = etDescription.getText().toString();
                float cantidad = Float.parseFloat(etAmount.getText().toString());

                // Obtener los valores del formulario
                String description = descripcion;
                double amount = cantidad;

                // Crear una nueva transacción
                Transaction transaction = new Transaction(accountId, categoryId, description, amount, type);

                // Insertar la transacción en la base de datos
                boolean result = dbHelper.insertTransaction(transaction);

                if (result) {
                    // Éxito al insertar la transacción
                    Toast.makeText(MainActivity.this, "Transacción agregada correctamente", Toast.LENGTH_SHORT).show();
                    dialog.dismiss(); // Cerrar el diálogo
                    loadTransactionsByAccountId(); // Actualizar la lista de transacciones
                } else {
                    // Error al insertar la transacción
                    Toast.makeText(MainActivity.this, "Error al agregar transacción", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }

    private void loadAccounts() {
        // Obtener las categorías de la base de datos
        List<Account> accounts = dbHelper.getAllAccounts();

        // Declarar lista para almacenar los nombres de las cuentas
        List<String> accountNames = new ArrayList<>();

        // Llenar lista de nombres y crear un mapa para asociar nombres con IDs

        for (Account account : accounts) {
            accountNames.add(account.getName());
            accountMap.put(account.getName(), account.getId());
        }

        // Crear un ArrayAdapter para el spinner y establecerlo
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, accountNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnAccount.setAdapter(adapter);
    }

    private double calculateTotalAmount() {
        // Llenar lista de transacciones
        transactionsList = dbHelper.getAllTransactionsByAccountId(accountId);

        double totalIncome = 0;
        double totalExpense = 0;

        for (Transaction transaction : transactionsList) {

            if (transaction.getType() == 1) {
                // Es una transacción de ingreso
                totalIncome += transaction.getAmount();
            } else if (transaction.getType() == 0) {
                // Es una transacción de egreso
                totalExpense += transaction.getAmount();
            }
        }

        double total = totalIncome - totalExpense;

        tvBalance.setText("$ " + String.valueOf(total));

        return total;
    }
}


