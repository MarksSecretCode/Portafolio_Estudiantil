package com.example.financemanager.models;

import android.content.Context;

import com.example.financemanager.DBHelper;

public class Transaction {
    private int id;
    private int accountId;
    private int categoryId;
    private String description;
    private double amount;
    private int type; // Puede ser 1 para ingreso y 0 para gasto

    private DBHelper dbHelper;

    public Transaction(Context context) {
        dbHelper = new DBHelper(context);
    }

    public Transaction(int accountId, int categoryId, String description, double amount, int type) {
        this.accountId = accountId;
        this.categoryId = categoryId;
        this.description = description;
        this.amount = amount;
        this.type = type;
    }

    public Transaction(int id, int accountId, int categoryId, String description, double amount, int type) {
        this.id = id;
        this.accountId = accountId;
        this.categoryId = categoryId;
        this.description = description;
        this.amount = amount;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", accountId=" + accountId +
                ", categoryId=" + categoryId +
                ", description='" + description + '\'' +
                ", amount=" + amount +
                ", type=" + type +
                '}';
    }

    public String getCategoryName(int categoryId) {
        return dbHelper.getCategoryNameById(categoryId);
    }
}

